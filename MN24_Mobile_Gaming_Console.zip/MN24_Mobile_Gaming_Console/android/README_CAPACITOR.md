# Empaquetar MN24 Console como APK con Capacitor

## Requisitos previos

- Node.js LTS
- Android Studio (o SDK + Gradle)
- Cuenta de desarrollador de Google (solo para publicar en Play Store)

## Pasos (resumen)

```bash
# 1. Crear proyecto Capacitor vacío
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "MN24 Console" "ia.mn24.console" --web-dir console

# 2. Copiar el contenido de la carpeta console/ al web-dir
# (o apuntar web-dir a la carpeta console existente)

# 3. Añadir plataforma Android
npx cap add android

# 4. Sincronizar
npx cap sync android

# 5. Abrir en Android Studio
npx cap open android
```

Desde Android Studio:

- Build → Generate Signed Bundle / APK
- O ejecutar en dispositivo/emulador con el botón Run.

## Notas importantes

- La Gamepad API funciona dentro del WebView de Capacitor en la mayoría de dispositivos modernos.
- Para vibración y permisos adicionales se pueden usar plugins de Capacitor.
- El modo fullscreen se puede forzar desde el `AndroidManifest.xml` y estilos de tema.
- **No se incluye código nativo de DualSense avanzado** en esta fase; se usa la API estándar del navegador/WebView.

## Estado

**PARCIAL** — La guía está lista. El APK concreto debe generarse en tu máquina con Android Studio.
