#!/data/data/com.termux/files/usr/bin/bash
# MN24 Mobile Gaming Console — Servidor local para Termux
# Uso: bash serve.sh   (desde la carpeta termux/ o ajusta la ruta)

set -e

# Detectar la carpeta console relativa a este script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONSOLE_DIR="$(cd "$SCRIPT_DIR/../console" && pwd)"

if [ ! -f "$CONSOLE_DIR/index.html" ]; then
  echo "ERROR: No se encontró index.html en $CONSOLE_DIR"
  exit 1
fi

echo "=========================================="
echo "  MN24 Mobile Gaming Console"
echo "  Servidor local — Termux"
echo "=========================================="
echo ""
echo "Carpeta: $CONSOLE_DIR"
echo ""

# Instalar python si no está
if ! command -v python >/dev/null 2>&1; then
  echo "Instalando Python..."
  pkg update -y && pkg install -y python
fi

cd "$CONSOLE_DIR"

# Obtener IP local (si está disponible)
IP=$(ip -4 addr show wlan0 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}' || echo "127.0.0.1")

echo "Abre en el navegador del teléfono:"
echo "  → http://127.0.0.1:8080"
echo ""
echo "Desde otro dispositivo en la misma Wi-Fi:"
echo "  → http://${IP}:8080"
echo ""
echo "Presiona Ctrl+C para detener."
echo "=========================================="

python -m http.server 8080 --bind 0.0.0.0
