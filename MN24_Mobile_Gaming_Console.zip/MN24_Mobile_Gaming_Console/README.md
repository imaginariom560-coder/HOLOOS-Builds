# MN24 Mobile Gaming Console v1.0 MVP

**Marca:** MN24 STUDIOS IA  
**Lema:** From Earth · Remote · AI  
**Tipo:** Consola universal táctil + mandos Bluetooth + modo TV  
**Estado del MVP web:** IMPLEMENTADA Y PROBADA

## Qué incluye este paquete

- Shell de consola con biblioteca de juegos
- Controles táctiles (joystick virtual + botones A/B/X/Y)
- Soporte nativo de mandos Bluetooth (Gamepad API)
- Demo jugable: **STORMRUNER** (Action · Dark Fantasy)
- PWA instalable (manifest + Service Worker)
- Script listo para Termux
- Guía para empaquetar APK con Capacitor
- Documentación de arquitectura e implementación

## Inicio rápido (Termux)

```bash
# Copia la carpeta completa a tu teléfono
cd ruta/a/MN24_Mobile_Gaming_Console/termux
bash serve.sh
# Abre http://127.0.0.1:8080 en Chrome
```

## Controles

| Entrada              | Acción          |
|----------------------|-----------------|
| Joystick / WASD      | Mover           |
| Botón A / Z          | Atacar          |
| Botón B / X          | Dash            |
| Start (mando) / Esc  | Pausa           |

## Estructura

```
MN24_Mobile_Gaming_Console/
├── README.md
├── docs/
│   ├── ARCHITECTURE.md
│   └── IMPLEMENTATION.md
├── console/                 ← Código ejecutable (PWA)
│   ├── index.html
│   ├── styles.css
│   ├── manifest.webmanifest
│   ├── sw.js
│   ├── js/
│   │   ├── input.js
│   │   ├── loader.js
│   │   └── shell.js
│   └── games/demo/game.js
├── android/README_CAPACITOR.md
├── termux/serve.sh
└── replit/README.md
```

## Evaluación rápida (Primera Tarea)

| Componente                    | Estado                      |
|-------------------------------|-----------------------------|
| MN24 Mobile Gaming Console MVP| **IMPLEMENTADA Y PROBADA**  |
| Controles táctiles + Gamepad  | **IMPLEMENTADA**            |
| Demo STORMRUNER               | **IMPLEMENTADA**            |
| PWA                           | **IMPLEMENTADA**            |
| APK nativo                    | PARCIAL (guía Capacitor)    |
| Game Services (perfiles)      | PARCIAL                     |
| Cloud / Remote Play           | PENDIENTE                   |
| MN24 Software Factory         | PROPUESTA (siguiente fase)  |

## Siguiente objetivo recomendado

1. Probar este MVP en tu teléfono Android + mando Bluetooth.
2. Empaquetar con Capacitor → APK.
3. Usar la consola como demo comercial / portafolio.
4. Empezar el primer producto de Software Factory (app de inventario o reservas simple).

---
MN24 STUDIOS IA · 2026
