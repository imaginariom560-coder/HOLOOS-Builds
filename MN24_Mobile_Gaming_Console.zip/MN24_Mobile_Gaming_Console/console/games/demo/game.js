/**
 * STORMRUNER Demo — Mini Action Prototype
 * Controles: mover con joystick / WASD, A = atacar, B = dash
 * Objetivo: sobrevivir y derrotar enemigos.
 */

export function createGame(canvas, ctx) {
  const W = canvas.width;
  const H = canvas.height;

  // Player
  const player = {
    x: W / 2,
    y: H / 2,
    r: 14,
    speed: 180,
    hp: 100,
    maxHp: 100,
    attackCooldown: 0,
    dashCooldown: 0,
    invuln: 0,
    facing: 1
  };

  // Enemies
  let enemies = [];
  let spawnTimer = 0;
  let score = 0;
  let gameOver = false;
  let particles = [];

  function spawnEnemy() {
    const side = Math.floor(Math.random() * 4);
    let x, y;
    if (side === 0) { x = Math.random() * W; y = -20; }
    else if (side === 1) { x = W + 20; y = Math.random() * H; }
    else if (side === 2) { x = Math.random() * W; y = H + 20; }
    else { x = -20; y = Math.random() * H; }

    enemies.push({
      x, y,
      r: 12 + Math.random() * 6,
      speed: 40 + Math.random() * 50,
      hp: 30
    });
  }

  function addParticles(x, y, color, n = 8) {
    for (let i = 0; i < n; i++) {
      particles.push({
        x, y,
        vx: (Math.random() - 0.5) * 120,
        vy: (Math.random() - 0.5) * 120,
        life: 0.4 + Math.random() * 0.3,
        color
      });
    }
  }

  function update(input, dt) {
    if (gameOver) return;

    // Movement
    const ax = input.axes.x;
    const ay = input.axes.y;
    const len = Math.sqrt(ax * ax + ay * ay) || 1;
    player.x += (ax / len) * player.speed * dt * (len > 0.1 ? 1 : 0);
    player.y += (ay / len) * player.speed * dt * (len > 0.1 ? 1 : 0);
    if (ax !== 0) player.facing = ax > 0 ? 1 : -1;

    // Clamp
    player.x = Math.max(player.r, Math.min(W - player.r, player.x));
    player.y = Math.max(player.r, Math.min(H - player.r, player.y));

    // Cooldowns
    if (player.attackCooldown > 0) player.attackCooldown -= dt;
    if (player.dashCooldown > 0) player.dashCooldown -= dt;
    if (player.invuln > 0) player.invuln -= dt;

    // Attack (A)
    if (input.buttons.a && player.attackCooldown <= 0) {
      player.attackCooldown = 0.35;
      // Hitbox en dirección de facing
      const hx = player.x + player.facing * 28;
      const hy = player.y;
      enemies = enemies.filter((e) => {
        const dx = e.x - hx;
        const dy = e.y - hy;
        if (dx * dx + dy * dy < (e.r + 20) ** 2) {
          e.hp -= 25;
          addParticles(e.x, e.y, '#22d3ee');
          if (e.hp <= 0) {
            score += 10;
            addParticles(e.x, e.y, '#a78bfa', 12);
            return false;
          }
        }
        return true;
      });
    }

    // Dash (B)
    if (input.buttons.b && player.dashCooldown <= 0) {
      player.dashCooldown = 0.8;
      player.invuln = 0.25;
      const dx = ax || player.facing;
      const dy = ay;
      const dlen = Math.sqrt(dx * dx + dy * dy) || 1;
      player.x += (dx / dlen) * 55;
      player.y += (dy / dlen) * 55;
      addParticles(player.x, player.y, '#7c3aed', 6);
    }

    // Spawn enemies
    spawnTimer -= dt;
    if (spawnTimer <= 0) {
      spawnEnemy();
      spawnTimer = Math.max(0.6, 1.8 - score * 0.01);
    }

    // Move enemies toward player
    for (const e of enemies) {
      const dx = player.x - e.x;
      const dy = player.y - e.y;
      const d = Math.sqrt(dx * dx + dy * dy) || 1;
      e.x += (dx / d) * e.speed * dt;
      e.y += (dy / d) * e.speed * dt;

      // Collision
      if (player.invuln <= 0 && d < player.r + e.r) {
        player.hp -= 12;
        player.invuln = 0.6;
        addParticles(player.x, player.y, '#ef4444');
        if (player.hp <= 0) {
          player.hp = 0;
          gameOver = true;
        }
      }
    }

    // Particles
    particles = particles.filter((p) => {
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.life -= dt;
      return p.life > 0;
    });
  }

  function render() {
    // Background
    ctx.fillStyle = '#0a0a14';
    ctx.fillRect(0, 0, W, H);

    // Grid subtle
    ctx.strokeStyle = 'rgba(124,58,237,0.08)';
    ctx.lineWidth = 1;
    for (let x = 0; x < W; x += 40) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    }
    for (let y = 0; y < H; y += 40) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }

    // Particles
    for (const p of particles) {
      ctx.globalAlpha = Math.max(0, p.life * 2);
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, 3, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    // Enemies
    for (const e of enemies) {
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(e.x, e.y, e.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#fca5a5';
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    // Player
    if (player.invuln > 0 && Math.floor(player.invuln * 10) % 2 === 0) {
      ctx.globalAlpha = 0.4;
    }
    // Body
    ctx.fillStyle = '#7c3aed';
    ctx.beginPath();
    ctx.arc(player.x, player.y, player.r, 0, Math.PI * 2);
    ctx.fill();
    // Eye / facing
    ctx.fillStyle = '#22d3ee';
    ctx.beginPath();
    ctx.arc(player.x + player.facing * 5, player.y - 3, 4, 0, Math.PI * 2);
    ctx.fill();
    // Attack flash
    if (player.attackCooldown > 0.2) {
      ctx.strokeStyle = '#22d3ee';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(player.x + player.facing * 28, player.y, 18, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;

    // HUD
    // HP bar
    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    ctx.fillRect(16, 16, 160, 14);
    ctx.fillStyle = player.hp > 30 ? '#22c55e' : '#ef4444';
    ctx.fillRect(16, 16, 160 * (player.hp / player.maxHp), 14);
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 1;
    ctx.strokeRect(16, 16, 160, 14);

    // Score
    ctx.fillStyle = '#f1f5f9';
    ctx.font = 'bold 16px system-ui';
    ctx.fillText(`Score: ${score}`, 16, 50);

    // Cooldowns
    ctx.font = '12px system-ui';
    ctx.fillStyle = '#94a3b8';
    ctx.fillText(`A: ataque  B: dash`, 16, H - 20);

    if (gameOver) {
      ctx.fillStyle = 'rgba(0,0,0,0.7)';
      ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = '#f1f5f9';
      ctx.font = 'bold 36px system-ui';
      ctx.textAlign = 'center';
      ctx.fillText('GAME OVER', W / 2, H / 2 - 20);
      ctx.font = '18px system-ui';
      ctx.fillText(`Puntuación: ${score}`, W / 2, H / 2 + 20);
      ctx.fillText('Sal de la consola y vuelve a entrar', W / 2, H / 2 + 50);
      ctx.textAlign = 'left';
    }
  }

  function destroy() {
    enemies = [];
    particles = [];
  }

  return { update, render, destroy };
}
