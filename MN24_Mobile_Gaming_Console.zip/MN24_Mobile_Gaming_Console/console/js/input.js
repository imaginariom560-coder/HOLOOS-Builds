/**
 * MN24 Input Layer
 * - Virtual joystick + buttons (Pointer Events)
 * - Gamepad API (Bluetooth controllers)
 * - Keyboard fallback for desktop testing
 * Normaliza todo a un estado único: { axes: {x,y}, buttons: {a,b,x,y,start} }
 */

export class InputManager {
  constructor() {
    this.state = {
      axes: { x: 0, y: 0 },
      buttons: { a: false, b: false, x: false, y: false, start: false },
      source: 'none' // 'touch' | 'gamepad' | 'keyboard'
    };

    this.listeners = [];
    this.gamepads = [];
    this.vibrationEnabled = true;
    this._joystickActive = false;
    this._knob = null;
    this._base = null;
    this._center = { x: 0, y: 0 };
    this._maxRadius = 40;

    this._bindKeyboard();
    this._pollGamepads();
  }

  onChange(fn) {
    this.listeners.push(fn);
  }

  _emit() {
    for (const fn of this.listeners) fn(this.state);
  }

  /* ========== VIRTUAL JOYSTICK ========== */
  initVirtualJoystick(baseEl, knobEl) {
    this._base = baseEl;
    this._knob = knobEl;

    const zone = baseEl.parentElement;

    const start = (e) => {
      e.preventDefault();
      this._joystickActive = true;
      const rect = baseEl.getBoundingClientRect();
      this._center = {
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2
      };
      this._move(e);
    };

    const move = (e) => {
      if (!this._joystickActive) return;
      e.preventDefault();
      this._move(e);
    };

    const end = (e) => {
      if (!this._joystickActive) return;
      e.preventDefault();
      this._joystickActive = false;
      this.state.axes.x = 0;
      this.state.axes.y = 0;
      this.state.source = this.gamepads.length ? 'gamepad' : 'touch';
      if (this._knob) {
        this._knob.style.transform = 'translate(-50%, -50%)';
      }
      this._emit();
    };

    zone.addEventListener('pointerdown', start, { passive: false });
    window.addEventListener('pointermove', move, { passive: false });
    window.addEventListener('pointerup', end, { passive: false });
    window.addEventListener('pointercancel', end, { passive: false });
  }

  _move(e) {
    const point = e.touches ? e.touches[0] : e;
    let dx = point.clientX - this._center.x;
    let dy = point.clientY - this._center.y;
    const dist = Math.sqrt(dx * dx + dy * dy);

    if (dist > this._maxRadius) {
      dx = (dx / dist) * this._maxRadius;
      dy = (dy / dist) * this._maxRadius;
    }

    if (this._knob) {
      this._knob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
    }

    this.state.axes.x = +(dx / this._maxRadius).toFixed(3);
    this.state.axes.y = +(dy / this._maxRadius).toFixed(3);
    this.state.source = 'touch';
    this._emit();
  }

  /* ========== VIRTUAL BUTTONS ========== */
  initVirtualButtons(container) {
    const buttons = container.querySelectorAll('.vbtn');
    buttons.forEach((btn) => {
      const key = btn.dataset.btn;
      const press = (e) => {
        e.preventDefault();
        btn.classList.add('pressed');
        this.state.buttons[key] = true;
        this.state.source = 'touch';
        this._emit();
        this._vibrate(30);
      };
      const release = (e) => {
        e.preventDefault();
        btn.classList.remove('pressed');
        this.state.buttons[key] = false;
        this._emit();
      };
      btn.addEventListener('pointerdown', press, { passive: false });
      btn.addEventListener('pointerup', release, { passive: false });
      btn.addEventListener('pointerleave', release, { passive: false });
      btn.addEventListener('pointercancel', release, { passive: false });
    });
  }

  /* ========== GAMEPAD API ========== */
  _pollGamepads() {
    const poll = () => {
      const pads = navigator.getGamepads ? navigator.getGamepads() : [];
      this.gamepads = [];

      for (const pad of pads) {
        if (!pad) continue;
        this.gamepads.push(pad);

        // Axes (left stick)
        const ax = pad.axes[0] || 0;
        const ay = pad.axes[1] || 0;
        // Deadzone
        this.state.axes.x = Math.abs(ax) > 0.15 ? +ax.toFixed(3) : 0;
        this.state.axes.y = Math.abs(ay) > 0.15 ? +ay.toFixed(3) : 0;

        // Standard mapping: 0=A, 1=B, 2=X, 3=Y, 9=Start
        this.state.buttons.a = !!(pad.buttons[0] && pad.buttons[0].pressed);
        this.state.buttons.b = !!(pad.buttons[1] && pad.buttons[1].pressed);
        this.state.buttons.x = !!(pad.buttons[2] && pad.buttons[2].pressed);
        this.state.buttons.y = !!(pad.buttons[3] && pad.buttons[3].pressed);
        this.state.buttons.start = !!(pad.buttons[9] && pad.buttons[9].pressed);

        this.state.source = 'gamepad';
      }

      this._emit();
      requestAnimationFrame(poll);
    };
    requestAnimationFrame(poll);

    window.addEventListener('gamepadconnected', (e) => {
      console.log('[MN24] Gamepad connected:', e.gamepad.id);
      this._vibrate(50);
    });
    window.addEventListener('gamepaddisconnected', (e) => {
      console.log('[MN24] Gamepad disconnected:', e.gamepad.id);
    });
  }

  getConnectedGamepads() {
    return this.gamepads.map((p) => ({
      id: p.id,
      index: p.index,
      buttons: p.buttons.length,
      axes: p.axes.length
    }));
  }

  /* ========== KEYBOARD (desktop testing) ========== */
  _bindKeyboard() {
    const map = {
      KeyW: 'up', ArrowUp: 'up',
      KeyS: 'down', ArrowDown: 'down',
      KeyA: 'left', ArrowLeft: 'left',
      KeyD: 'right', ArrowRight: 'right',
      KeyZ: 'a', KeyX: 'b', KeyC: 'x', KeyV: 'y',
      Enter: 'start', Escape: 'start'
    };

    const keys = {};
    window.addEventListener('keydown', (e) => {
      const action = map[e.code];
      if (!action) return;
      e.preventDefault();
      keys[action] = true;
      this._applyKeys(keys);
    });
    window.addEventListener('keyup', (e) => {
      const action = map[e.code];
      if (!action) return;
      keys[action] = false;
      this._applyKeys(keys);
    });
  }

  _applyKeys(keys) {
    this.state.axes.x = (keys.right ? 1 : 0) - (keys.left ? 1 : 0);
    this.state.axes.y = (keys.down ? 1 : 0) - (keys.up ? 1 : 0);
    this.state.buttons.a = !!keys.a;
    this.state.buttons.b = !!keys.b;
    this.state.buttons.x = !!keys.x;
    this.state.buttons.y = !!keys.y;
    this.state.buttons.start = !!keys.start;
    this.state.source = 'keyboard';
    this._emit();
  }

  /* ========== HAPTICS ========== */
  _vibrate(ms) {
    if (!this.vibrationEnabled) return;
    if (navigator.vibrate) navigator.vibrate(ms);
  }

  setVibration(enabled) {
    this.vibrationEnabled = enabled;
  }
}
