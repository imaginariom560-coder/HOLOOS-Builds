/**
 * MN24 Console Shell
 * Orquesta pantallas, input, loader y UI.
 */

import { InputManager } from './input.js';
import { GameLoader, GAMES } from './loader.js';

const $ = (sel) => document.querySelector(sel);

class Shell {
  constructor() {
    this.input = new InputManager();
    this.loader = null;
    this.lastTime = 0;
    this.paused = false;
    this.showVirtual = true;

    this._cacheDOM();
    this._bindUI();
    this._buildLibrary();
    this._startLoop();
    this._registerSW();
  }

  _cacheDOM() {
    this.screens = {
      library: $('#library-screen'),
      game: $('#game-screen'),
      settings: $('#settings-screen')
    };
    this.canvas = $('#game-canvas');
    this.overlay = $('#game-overlay');
    this.virtualControls = $('#virtual-controls');
    this.gamepadStatus = $('#gamepad-status');
    this.inputMode = $('#input-mode');
    this.gamepadList = $('#gamepad-list');
  }

  _bindUI() {
    // Biblioteca → Juego
    // (se hace en _buildLibrary)

    // Pausa
    $('#btn-pause').addEventListener('click', () => this.togglePause());
    $('#btn-resume').addEventListener('click', () => this.togglePause(false));
    $('#btn-exit').addEventListener('click', () => this.exitGame());

    // Ajustes
    $('#btn-settings').addEventListener('click', () => this.showScreen('settings'));
    $('#btn-back-settings').addEventListener('click', () => this.showScreen('library'));

    $('#toggle-virtual').addEventListener('change', (e) => {
      this.showVirtual = e.target.checked;
      this._updateVirtualVisibility();
    });

    $('#toggle-vibration').addEventListener('change', (e) => {
      this.input.setVibration(e.target.checked);
    });

    $('#btn-fullscreen').addEventListener('click', () => {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen?.();
        document.body.classList.add('fullscreen');
      } else {
        document.exitFullscreen?.();
        document.body.classList.remove('fullscreen');
      }
    });

    // Input → actualizar UI de estado
    this.input.onChange((state) => {
      this._updateStatusUI(state);
      // Start button del mando = pausa
      if (state.buttons.start && this.screens.game.classList.contains('active')) {
        this.togglePause();
      }
    });

    // Virtual controls
    this.input.initVirtualJoystick($('#joystick-base'), $('#joystick-knob'));
    this.input.initVirtualButtons($('#buttons-zone'));
  }

  _buildLibrary() {
    const grid = $('#game-grid');
    grid.innerHTML = '';
    GAMES.forEach((g) => {
      const card = document.createElement('div');
      card.className = 'game-card';
      card.innerHTML = `
        <div class="cover">${g.icon}</div>
        <div class="info">
          <div class="title">${g.title}</div>
          <div class="meta">${g.meta}</div>
        </div>
      `;
      card.addEventListener('click', () => {
        if (g.module) this.startGame(g.id);
        else alert('Este juego estará disponible pronto.');
      });
      grid.appendChild(card);
    });
  }

  showScreen(name) {
    Object.values(this.screens).forEach((s) => s.classList.remove('active'));
    this.screens[name].classList.add('active');
  }

  async startGame(gameId) {
    this.loader = new GameLoader(this.canvas);
    try {
      await this.loader.load(gameId);
      this.paused = false;
      this.overlay.classList.add('hidden');
      this.showScreen('game');
      this._updateVirtualVisibility();
      // Ajustar canvas al tamaño disponible
      this._resizeCanvas();
    } catch (err) {
      console.error(err);
      alert('No se pudo cargar el juego: ' + err.message);
    }
  }

  exitGame() {
    if (this.loader) this.loader.unload();
    this.loader = null;
    this.paused = false;
    this.showScreen('library');
  }

  togglePause(force) {
    this.paused = typeof force === 'boolean' ? force : !this.paused;
    this.overlay.classList.toggle('hidden', !this.paused);
    $('#overlay-title').textContent = this.paused ? 'Pausa' : '';
  }

  _updateVirtualVisibility() {
    const hasGamepad = this.input.gamepads.length > 0;
    const show = this.showVirtual && !hasGamepad;
    this.virtualControls.classList.toggle('hidden', !show);
  }

  _updateStatusUI(state) {
    const pads = this.input.getConnectedGamepads();
    const hasPad = pads.length > 0;

    const dot = this.gamepadStatus.querySelector('.dot');
    const label = this.gamepadStatus.querySelector('span:last-child');
    dot.classList.toggle('online', hasPad);
    dot.classList.toggle('offline', !hasPad);
    label.textContent = hasPad ? `${pads.length} mando(s)` : 'Sin mando';

    this.inputMode.textContent =
      state.source === 'gamepad' ? 'Mando' :
      state.source === 'keyboard' ? 'Teclado' : 'Táctil';

    if (this.gamepadList) {
      this.gamepadList.textContent = hasPad
        ? pads.map((p) => p.id.slice(0, 40)).join('\n')
        : 'Ninguno';
    }

    this._updateVirtualVisibility();
  }

  _resizeCanvas() {
    // Mantiene aspect 16:9 aproximadamente
    const container = $('#game-container');
    const maxW = container.clientWidth;
    const maxH = container.clientHeight * 0.95;
    let w = 800;
    let h = 450;
    const scale = Math.min(maxW / w, maxH / h);
    this.canvas.style.width = `${w * scale}px`;
    this.canvas.style.height = `${h * scale}px`;
  }

  _startLoop() {
    const loop = (time) => {
      const dt = Math.min((time - this.lastTime) / 1000, 0.05);
      this.lastTime = time;

      if (this.loader && this.loader.running && !this.paused) {
        this.loader.update(this.input.state, dt);
        this.loader.render();
      }
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);

    window.addEventListener('resize', () => {
      if (this.screens.game.classList.contains('active')) this._resizeCanvas();
    });
  }

  _registerSW() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
  }
}

// Boot
document.addEventListener('DOMContentLoaded', () => {
  window.mn24 = new Shell();
  console.log('[MN24] Mobile Gaming Console lista');
});
