/**
 * MN24 Game Loader
 * Carga y gestiona los juegos de la biblioteca.
 */

export const GAMES = [
  {
    id: 'stormrunner-demo',
    title: 'STORMRUNER Demo',
    meta: 'Action · Dark Fantasy',
    icon: '⚡',
    module: './games/demo/game.js'
  },
  {
    id: 'space-dash',
    title: 'MN24 Space Dash',
    meta: 'Próximamente',
    icon: '🚀',
    module: null // placeholder
  },
  {
    id: 'retro-lab',
    title: 'MN24 Retro Lab',
    meta: 'Próximamente',
    icon: '👾',
    module: null
  }
];

export class GameLoader {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.currentGame = null;
    this.running = false;
  }

  async load(gameId) {
    const entry = GAMES.find((g) => g.id === gameId);
    if (!entry || !entry.module) {
      throw new Error(`Juego no disponible: ${gameId}`);
    }

    // Detener juego anterior
    this.unload();

    const mod = await import(entry.module);
    this.currentGame = mod.createGame(this.canvas, this.ctx);
    this.running = true;
    return this.currentGame;
  }

  unload() {
    if (this.currentGame && typeof this.currentGame.destroy === 'function') {
      this.currentGame.destroy();
    }
    this.currentGame = null;
    this.running = false;
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
  }

  update(inputState, dt) {
    if (this.running && this.currentGame) {
      this.currentGame.update(inputState, dt);
    }
  }

  render() {
    if (this.running && this.currentGame) {
      this.currentGame.render();
    }
  }
}
