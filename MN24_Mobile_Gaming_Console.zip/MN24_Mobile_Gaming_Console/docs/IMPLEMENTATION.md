# MN24 Mobile Gaming Console — Guía de Implementación

## Estado actual del MVP (2026-10-13)

| Fase | Descripción                          | Estado                    |
|------|--------------------------------------|---------------------------|
| 1    | Shell web + controles + demo         | **IMPLEMENTADA Y PROBADA** |
| 2    | PWA instalable                       | **IMPLEMENTADA**          |
| 3    | Gamepad API (Bluetooth)              | **IMPLEMENTADA**          |
| 4    | Termux serve script                  | **IMPLEMENTADA**          |
| 5    | Capacitor / APK                      | PARCIAL (guía lista)      |
| 6    | Game Services (perfiles, guardados)  | PARCIAL                   |
| 7    | Cloud / Remote Play                  | PENDIENTE                 |

## Cómo probar AHORA (recomendado)

### Opción A — Termux (teléfono Android)

```bash
# 1. Copia toda la carpeta MN24_Mobile_Gaming_Console a tu teléfono
# 2. En Termux:
pkg update && pkg install python
cd ~/storage/shared/MN24_Mobile_Gaming_Console/console   # o la ruta donde la copiaste
python -m http.server 8080 --bind 0.0.0.0
```

Abre en Chrome/Firefox del mismo teléfono:  
`http://127.0.0.1:8080`  
o desde otro dispositivo en la misma red: `http://IP-DEL-TELEFONO:8080`

### Opción B — Replit

1. Crea un proyecto **HTML/CSS/JS**.
2. Sube el contenido de la carpeta `console/`.
3. Ejecuta y abre la vista previa.
4. Publica (HTTPS) para poder instalar como PWA.

### Opción C — Navegador de escritorio

Abre `console/index.html` directamente o sirve con cualquier servidor local.

## Controles

- **Táctil**: joystick virtual (izquierda) + botones A/B/X/Y (derecha).
- **Mando Bluetooth**: empareja desde Ajustes de Android → se detecta automáticamente.
- **Teclado** (para pruebas en PC): WASD / flechas + Z X C V.

## Estructura de archivos entregada

```
MN24_Mobile_Gaming_Console/
├── docs/
│   ├── ARCHITECTURE.md
│   └── IMPLEMENTATION.md
├── console/
│   ├── index.html
│   ├── styles.css
│   ├── manifest.webmanifest
│   ├── sw.js
│   ├── js/
│   │   ├── input.js
│   │   ├── loader.js
│   │   └── shell.js
│   └── games/
│       └── demo/
│           └── game.js
├── android/
│   └── README_CAPACITOR.md
├── termux/
│   └── serve.sh
└── replit/
    └── README.md
```

## Próximo objetivo técnico recomendado

1. Probar el demo en tu teléfono real + mando Bluetooth.
2. Empaquetar con Capacitor (ver `android/README_CAPACITOR.md`).
3. Añadir un segundo juego propio (MN24 Space Dash mínimo).
4. Implementar perfiles locales y pantalla de biblioteca más rica.

## Objetivo comercial inmediato

Usar esta consola como **demostración viva** de MN24 Studios IA:

- Mostrar en portafolio / LinkedIn / Upwork.
- Ofrecer “Consola personalizada + juegos propios” como servicio.
- Validar demanda de apps de entretenimiento mobile-first.
