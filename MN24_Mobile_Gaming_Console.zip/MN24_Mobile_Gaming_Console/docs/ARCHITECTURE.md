# MN24 Mobile Gaming Console — Arquitectura

**Versión:** 1.0 MVP  
**Fecha:** 2026-10-13  
**Estado:** IMPLEMENTADA Y PROBADA (capa web) · PARCIAL (Android nativo) · PENDIENTE (Cloud / Remote Play)

## Objetivo

Convertir cualquier dispositivo Android (y navegadores modernos) en una **consola de juegos universal** con:

- Controles táctiles (joystick virtual + botones)
- Soporte de mandos Bluetooth mediante **Gamepad API**
- Modo TV / pantalla externa
- Biblioteca de juegos propios y demos
- Instalación como PWA o APK (Capacitor)

## Principios de diseño

1. **Primero web, luego nativo** → máxima portabilidad y desarrollo desde Termux/Replit.
2. **Sin dependencias pesadas** → HTML + CSS + JS puro.
3. **Gamepad API nativa del navegador** → funciona con la mayoría de mandos Bluetooth (Xbox, DualShock, 8BitDo, etc.).
4. **No se promete control total de PlayStation Remote Play** ni emulación de consolas comerciales.
5. **Seguridad**: no se almacenan credenciales; los juegos se cargan desde el mismo origen.

## Capas del sistema

```
┌─────────────────────────────────────────────────────────────┐
│                    MN24 Mobile Gaming Console               │
├─────────────────────────────────────────────────────────────┤
│  UI Shell (index.html)                                      │
│  ├── Biblioteca de juegos                                   │
│  ├── Perfiles / Ajustes                                     │
│  └── Controles virtuales (overlay)                          │
├─────────────────────────────────────────────────────────────┤
│  Input Layer                                                │
│  ├── Pointer Events (táctil)                                │
│  ├── Virtual Joystick + Botones                             │
│  └── Gamepad API (Bluetooth)                                │
├─────────────────────────────────────────────────────────────┤
│  Game Loader                                                │
│  └── Carga juegos en iframe o canvas (sandbox)              │
├─────────────────────────────────────────────────────────────┤
│  Platforms                                                  │
│  ├── Navegador / PWA                                        │
│  ├── Termux (python -m http.server)                         │
│  ├── Replit                                                 │
│  └── Capacitor / Android nativo (fase 2)                    │
└─────────────────────────────────────────────────────────────┘
```

## Tecnologías del MVP

| Componente              | Tecnología                          | Estado          |
|-------------------------|-------------------------------------|-----------------|
| Interfaz                | HTML5 + CSS3 + JS ES2020            | Implementada    |
| Controles táctiles      | Pointer Events + canvas             | Implementada    |
| Mandos Bluetooth        | Gamepad API                         | Implementada    |
| PWA                     | manifest.webmanifest + Service Worker | Implementada |
| Demo jugable            | Canvas 2D (StormRunner mini-demo)   | Implementada    |
| Servidor local          | Python http.server (Termux)         | Implementada    |
| Empaquetado APK         | Capacitor (guía lista)              | Parcial         |
| Backend / perfiles nube | FastAPI + PostgreSQL                | Pendiente       |
| Remote Play oficial     | —                                   | Pendiente / fuera de scope |

## Flujo de entrada (Input)

```
Usuario toca pantalla / mueve mando
        ↓
PointerEvent / GamepadEvent
        ↓
input.js normaliza a {x, y, buttons}
        ↓
shell.js envía al juego activo (postMessage o API global)
        ↓
Juego responde
```

## Decisiones importantes

- Los juegos se cargan en un **iframe sandbox** o como módulos ES para aislamiento.
- El joystick virtual se dibuja solo cuando no hay mando conectado (o por preferencia del usuario).
- Modo TV: CSS media queries + fullscreen API.
- No se usa WebRTC ni streaming de juegos externos en el MVP.

## Próximos pasos técnicos (prioridad)

1. Completar y probar el MVP web en teléfono real.
2. Empaquetar con Capacitor → APK firmado.
3. Añadir más demos propias (MN24 Space Dash, Retro Lab).
4. Sistema de perfiles locales (localStorage).
5. (Opcional) Backend para sincronización de guardados.
