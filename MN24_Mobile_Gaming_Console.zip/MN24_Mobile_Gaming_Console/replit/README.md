# MN24 Mobile Gaming Console en Replit

## Cómo subir el proyecto

1. Crea un nuevo Repl → **HTML, CSS, JS**.
2. Borra los archivos por defecto.
3. Sube (o pega) todo el contenido de la carpeta `console/`:
   - index.html
   - styles.css
   - manifest.webmanifest
   - sw.js
   - js/ (carpeta completa)
   - games/ (carpeta completa)
4. Ejecuta el Repl.
5. Abre la vista previa.
6. (Opcional) Publica el Repl para obtener una URL HTTPS → podrás instalarlo como PWA en el teléfono.

## Controles en Replit / escritorio

- **WASD** o flechas → movimiento
- **Z** → ataque (A)
- **X** → dash (B)
- **C / V** → X / Y
- **Enter / Esc** → pausa

## Notas

- El Service Worker y la instalación PWA requieren HTTPS (la URL publicada de Replit lo tiene).
- Los mandos Bluetooth se detectan cuando abres la URL publicada desde el teléfono.
