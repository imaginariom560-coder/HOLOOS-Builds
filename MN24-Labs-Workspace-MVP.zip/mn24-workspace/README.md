# MN24 Labs Workspace — MVP 0.1

SaaS starter for remote work, coworking, projects/tasks, job listings, and an explicitly unconnected Claude/Anthropic status panel. Python 3.12 + FastAPI + SQLModel. Responsive frontend served by FastAPI.

## Included and working
- REST API with automatic OpenAPI docs at `/docs`.
- Projects CRUD start (create/list), remote tasks (create/list), coworking spaces (create/list), bookings (create/list), and job listings (create/list/search).
- Booking validation: valid space, end after start, overlapping reservation prevention.
- SQLite by default, configurable with `DATABASE_URL`.
- Responsive single-page frontend.
- Tests for health, project creation/listing, booking conflicts, unknown spaces and job search.

## Important limitations
- This is a development MVP, not a production-ready multi-tenant SaaS. Authentication, authorization, email verification, rate limiting, migrations, audit logs, payments, moderation, and privacy workflows must be added before public use.
- `ANTHROPIC_API_KEY` is only detected for status display. No Anthropic API request is implemented. Claude Cowork is a separate Anthropic product and is not embedded in this application.
- Job postings are user-entered sample data; no job board is connected and no vacancies are verified.
- Booking overlap checks are suitable for an MVP but need transaction/locking and capacity-aware logic for high concurrency and multiple seats.

## Run locally (Ubuntu, macOS, Termux with Python support)

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000` and API docs `http://127.0.0.1:8000/docs`.

If Python 3.12 is not available in Termux, install a supported Python package with `pkg install python` and use `python -m venv .venv`.

## Tests

```bash
pytest -q
```

## Docker

```bash
docker build -t mn24-workspace .
docker run --rm -p 8000:8000 -v "$PWD/data:/data" -e DATABASE_URL=sqlite:////data/mn24.db mn24-workspace
```

For production, use managed PostgreSQL and set `DATABASE_URL` to its SQLAlchemy-compatible connection URL. Use a hosting platform that supports persistent services and environment variables; static GitHub Pages alone cannot host this FastAPI backend.

## Deployment checklist
1. Push this directory to a GitHub repository.
2. Choose a Python-capable host (or Docker host) and connect the repository.
3. Set start command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT` (adapt if host requires a fixed port).
4. Configure a persistent PostgreSQL database and set `DATABASE_URL` privately in host settings.
5. Add HTTPS, backups, authentication/authorization, migrations, monitoring and rate limits before public launch.
6. Verify `/api/health`, `/docs`, data persistence and booking conflict tests on the deployed environment.

## Budget below US$100
The code can be developed and tested locally without paying for hosting. Actual deployment may fit free tiers, but provider limits and prices change; a custom domain, paid AI subscription/API usage, database or hosting upgrades can exceed the budget. Do not add secrets to Git.
