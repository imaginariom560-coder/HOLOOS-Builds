from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal
import os

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlmodel import Field, Session, SQLModel, create_engine, select

ROOT = Path(__file__).resolve().parent
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./mn24.db")
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)

class Project(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    title: str = Field(min_length=1, max_length=160)
    description: str = Field(default="", max_length=2000)
    status: str = Field(default="active", max_length=30)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ProjectIn(SQLModel):
    title: str = Field(min_length=1, max_length=160)
    description: str = Field(default="", max_length=2000)

class CoworkSpace(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    name: str = Field(min_length=1, max_length=160)
    city: str = Field(default="Remote", max_length=120)
    seats: int = Field(default=1, ge=1, le=10000)
    hourly_rate: float = Field(default=0, ge=0)

class SpaceIn(SQLModel):
    name: str = Field(min_length=1, max_length=160)
    city: str = Field(default="Remote", max_length=120)
    seats: int = Field(default=1, ge=1, le=10000)
    hourly_rate: float = Field(default=0, ge=0)

class Booking(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    space_id: int = Field(index=True, foreign_key="coworkspace.id")
    customer_email: str = Field(min_length=3, max_length=254)
    starts_at: datetime
    ends_at: datetime
    status: str = Field(default="requested", max_length=30)

class BookingIn(SQLModel):
    space_id: int
    customer_email: str = Field(min_length=3, max_length=254)
    starts_at: datetime
    ends_at: datetime

class Job(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    title: str = Field(min_length=1, max_length=160)
    company: str = Field(min_length=1, max_length=160)
    location: str = Field(default="Remote", max_length=120)
    job_type: str = Field(default="remote", max_length=40)
    description: str = Field(default="", max_length=3000)

class JobIn(SQLModel):
    title: str = Field(min_length=1, max_length=160)
    company: str = Field(min_length=1, max_length=160)
    location: str = Field(default="Remote", max_length=120)
    job_type: str = Field(default="remote", max_length=40)
    description: str = Field(default="", max_length=3000)

class Task(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    title: str = Field(min_length=1, max_length=200)
    owner: str = Field(default="me", max_length=120)
    status: str = Field(default="todo", max_length=30)

class TaskIn(SQLModel):
    title: str = Field(min_length=1, max_length=200)
    owner: str = Field(default="me", max_length=120)

@asynccontextmanager
async def lifespan(app: FastAPI):
    SQLModel.metadata.create_all(engine)
    yield

app = FastAPI(title="MN24 Labs Workspace API", version="0.1.0", lifespan=lifespan,
              description="MVP for remote work, coworking, jobs and AI-provider status.")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")

def get_session():
    with Session(engine) as session:
        yield session

@app.get("/", include_in_schema=False)
def home():
    return FileResponse(ROOT / "static" / "index.html")

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "mn24-workspace", "version": "0.1.0"}

@app.get("/api/projects", response_model=list[Project])
def list_projects(session: Session = Depends(get_session)):
    return session.exec(select(Project).order_by(Project.id.desc())).all()

@app.post("/api/projects", response_model=Project, status_code=201)
def create_project(payload: ProjectIn, session: Session = Depends(get_session)):
    item = Project.model_validate(payload)
    session.add(item); session.commit(); session.refresh(item)
    return item

@app.get("/api/spaces", response_model=list[CoworkSpace])
def list_spaces(session: Session = Depends(get_session)):
    return session.exec(select(CoworkSpace).order_by(CoworkSpace.id.desc())).all()

@app.post("/api/spaces", response_model=CoworkSpace, status_code=201)
def create_space(payload: SpaceIn, session: Session = Depends(get_session)):
    item = CoworkSpace.model_validate(payload)
    session.add(item); session.commit(); session.refresh(item)
    return item

@app.post("/api/bookings", response_model=Booking, status_code=201)
def create_booking(payload: BookingIn, session: Session = Depends(get_session)):
    space = session.get(CoworkSpace, payload.space_id)
    if not space:
        raise HTTPException(status_code=404, detail="Coworking space not found")
    if payload.ends_at <= payload.starts_at:
        raise HTTPException(status_code=422, detail="ends_at must be later than starts_at")
    overlaps = session.exec(select(Booking).where(
        Booking.space_id == payload.space_id,
        Booking.status != "cancelled",
        Booking.starts_at < payload.ends_at,
        Booking.ends_at > payload.starts_at,
    )).first()
    if overlaps:
        raise HTTPException(status_code=409, detail="This space already has a booking in that time range")
    item = Booking.model_validate(payload)
    session.add(item); session.commit(); session.refresh(item)
    return item

@app.get("/api/bookings", response_model=list[Booking])
def list_bookings(session: Session = Depends(get_session)):
    return session.exec(select(Booking).order_by(Booking.id.desc())).all()

@app.get("/api/jobs", response_model=list[Job])
def list_jobs(q: str | None = Query(default=None, max_length=120), session: Session = Depends(get_session)):
    rows = session.exec(select(Job).order_by(Job.id.desc())).all()
    if q:
        ql = q.casefold()
        rows = [x for x in rows if ql in x.title.casefold() or ql in x.company.casefold() or ql in x.description.casefold()]
    return rows

@app.post("/api/jobs", response_model=Job, status_code=201)
def create_job(payload: JobIn, session: Session = Depends(get_session)):
    item = Job.model_validate(payload)
    session.add(item); session.commit(); session.refresh(item)
    return item

@app.get("/api/tasks", response_model=list[Task])
def list_tasks(session: Session = Depends(get_session)):
    return session.exec(select(Task).order_by(Task.id.desc())).all()

@app.post("/api/tasks", response_model=Task, status_code=201)
def create_task(payload: TaskIn, session: Session = Depends(get_session)):
    item = Task.model_validate(payload)
    session.add(item); session.commit(); session.refresh(item)
    return item

@app.get("/api/integrations/claude")
def claude_status():
    configured = bool(os.getenv("ANTHROPIC_API_KEY"))
    return {"provider": "Anthropic API", "configured": configured,
            "status": "configured" if configured else "not_configured",
            "note": "This checks for an API key only; it does not connect to or embed Claude Cowork."}
