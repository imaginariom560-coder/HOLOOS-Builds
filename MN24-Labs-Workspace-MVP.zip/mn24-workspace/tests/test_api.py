import os
from pathlib import Path
from tempfile import TemporaryDirectory

# Give each test run its own database before importing the app.
tmp = TemporaryDirectory()
os.environ["DATABASE_URL"] = f"sqlite:///{Path(tmp.name) / 'test.db'}"
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    response = client.get('/api/health')
    assert response.status_code == 200
    assert response.json()['status'] == 'ok'

def test_project_create_and_list():
    created = client.post('/api/projects', json={'title': 'Test project', 'description': 'MVP'})
    assert created.status_code == 201
    assert created.json()['title'] == 'Test project'
    listed = client.get('/api/projects')
    assert any(p['title'] == 'Test project' for p in listed.json())

def test_booking_validates_space_and_overlap():
    space = client.post('/api/spaces', json={'name': 'Desk A', 'city': 'San José', 'seats': 2, 'hourly_rate': 3})
    assert space.status_code == 201
    sid = space.json()['id']
    payload = {'space_id': sid, 'customer_email': 'demo@example.com', 'starts_at': '2030-01-01T10:00:00Z', 'ends_at': '2030-01-01T11:00:00Z'}
    assert client.post('/api/bookings', json=payload).status_code == 201
    conflict = {**payload, 'customer_email': 'other@example.com', 'starts_at': '2030-01-01T10:30:00Z', 'ends_at': '2030-01-01T11:30:00Z'}
    assert client.post('/api/bookings', json=conflict).status_code == 409

def test_booking_rejects_unknown_space():
    payload = {'space_id': 99999, 'customer_email': 'demo@example.com', 'starts_at': '2030-01-01T10:00:00Z', 'ends_at': '2030-01-01T11:00:00Z'}
    assert client.post('/api/bookings', json=payload).status_code == 404

def test_jobs_search():
    assert client.post('/api/jobs', json={'title':'Python Developer','company':'MN24','location':'Remote','job_type':'remote','description':'FastAPI'}).status_code == 201
    assert any(j['title'] == 'Python Developer' for j in client.get('/api/jobs?q=python').json())
